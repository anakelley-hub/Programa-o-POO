public class Segundo {
    public static void main(String[] args) {
        System.out.println("Segunda Chamada");
    }
    
}
